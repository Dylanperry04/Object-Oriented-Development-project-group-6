import java.util.ArrayList;
import java.util.List;

public class PayRollSystem {
    private Employee employee;
    private List<Deductions> deductionsList;
    private double taxes;
    private double netPay;
    private String payDate;

    public PayRollSystem(Employee employee, List<Deductions> deductionsList, double taxes, String payDate) {
        this.employee = employee;
        this.deductionsList = deductionsList;
        this.taxes = taxes;
        this.payDate = payDate;
        this.netPay = calculateNetPay();
    }

    private double calculateNetPay() {
        double totalDeductions = Deductions.calculateTotalDeductions(deductionsList, employee.getEmployeeId());
        double grossPay = employee.calculateGrossPay();
        return grossPay - totalDeductions - taxes;
    }

    public double getTaxes() {
        return taxes;
    }

    public double getNetPay() {
        return netPay;
    }

    public String getPayDate() {
        return payDate;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void generatePayslip() {
        System.out.println("\n=== Pay Slip ===");
        System.out.println("Employee ID: " + employee.getEmployeeId());
        System.out.println("Name: " + employee.getName());
        System.out.println("Title: " + employee.getTitle());
        System.out.println("Gross Pay: " + employee.calculateGrossPay());
        System.out.println("Total Deductions: " + Deductions.calculateTotalDeductions(deductionsList, employee.getEmployeeId()));
        System.out.println("Taxes: " + taxes);
        System.out.println("Net Pay: " + netPay);
        System.out.println("Pay Date: " + payDate);
        System.out.println("-----------------------------");
    }

    // Static method to generate payslips
    public static List<PayRollSystem> generatePayslips(List<Employee> employees, List<Deductions> deductions, List<Tax> taxes, String payDate) {
        List<PayRollSystem> payslips = new ArrayList<>();

        for (Employee employee : employees) {
            List<Deductions> employeeDeductions = new ArrayList<>();
            double employeeTax = 0.0;

            // Filter deductions for the employee
            for (Deductions deduction : deductions) {
                if (deduction.getEmployeeId().equals(employee.getEmployeeId())) {
                    employeeDeductions.add(deduction);
                }
            }

            // Find taxes for the employee
            for (Tax tax : taxes) {
                if (tax.getEmployeeId().equals(employee.getEmployeeId())) {
                    employeeTax = tax.getTaxAmount();
                    break;
                }
            }

            // Create a new PayRollSystem object for the employee
            PayRollSystem payslip = new PayRollSystem(employee, employeeDeductions, employeeTax, payDate);
            payslips.add(payslip);
        }

        return payslips;
    }
}
