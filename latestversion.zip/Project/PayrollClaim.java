public class PayrollClaim {
    private String employeeId;
    private String claimDate;
    private double hoursWorked;
    private double hourlyRate;

    // Constructor
    public PayrollClaim(String employeeId, String claimDate, double hoursWorked, double hourlyRate) {
        this.employeeId = employeeId;
        this.claimDate = claimDate;
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
    }

    // Getters
    public String getEmployeeId() {
        return employeeId;
    }

    public String getClaimDate() {
        return claimDate;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    // Setters
    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public void setClaimDate(String claimDate) {
        this.claimDate = claimDate;
    }

    public void setHoursWorked(double hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }
}
