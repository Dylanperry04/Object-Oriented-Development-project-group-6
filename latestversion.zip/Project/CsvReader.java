import java.io.*;
import java.util.*;

public class CsvReader {

    public static List<Employee> readEmployees(String fileName) throws IOException {
        List<Employee> employees = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line;
        reader.readLine(); // Skip header

        while ((line = reader.readLine()) != null) {
            String[] columns = line.split(",");

            String employeeId = columns[0];
            String name = columns[1];
            String title = columns[2];
            int point = Integer.parseInt(columns[3]);
            double annualRate = Double.parseDouble(columns[4]);
            double hourlyRate = Double.parseDouble(columns[5]);
            String employmentType = columns[6];

            if ("fulltime".equalsIgnoreCase(employmentType)) {
                employees.add(new FullTimeEmployee(employeeId, name, title, point, annualRate));
            } else {
                employees.add(new PartTimeEmployee(employeeId, name, title, point, hourlyRate, 160));
            }
        }
        reader.close();
        return employees;
    }

    public static List<Deductions> readDeductions(String fileName) throws IOException {
        List<Deductions> deductions = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line;
        reader.readLine(); // Skip header

        while ((line = reader.readLine()) != null) {
            String[] columns = line.split(",");
            String employeeId = columns[0];
            String deductionName = columns[1];
            double amount = Double.parseDouble(columns[2]);
            String effectiveDate = columns[3];

            deductions.add(new Deductions(employeeId, deductionName, amount, effectiveDate));
        }
        reader.close();
        return deductions;
    }

    public static List<Tax> readTaxes(String fileName) throws IOException {
        List<Tax> taxes = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line;
        reader.readLine(); // Skip header

        while ((line = reader.readLine()) != null) {
            String[] columns = line.split(",");
            String employeeId = columns[0];
            double taxAmount = Double.parseDouble(columns[4]);

            taxes.add(new Tax(employeeId, taxAmount));
        }
        reader.close();
        return taxes;
    }

    public static List<PayScale> readPayScales(String fileName) throws IOException {
        List<PayScale> payScales = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line;
        reader.readLine(); // Skip header

        while ((line = reader.readLine()) != null) {
            // Skip empty or improperly formatted lines
            if (line.trim().isEmpty()) continue;

            String[] columns = line.split(",");

            // Ensure the row has at least 4 columns (title, point, annualRate, hourlyRate)
            if (columns.length < 4) {
                System.err.println("Skipping malformed line: " + line);
                continue;
            }

            try {
                String title = columns[0].trim();
                int point = Integer.parseInt(columns[1].trim());
                double annualRate = Double.parseDouble(columns[2].trim());
                double hourlyRate = Double.parseDouble(columns[3].trim());

                payScales.add(new PayScale(title, point, annualRate, hourlyRate));
            } catch (NumberFormatException e) {
                System.err.println("Skipping line with invalid number format: " + line);
            }
        }
        reader.close();
        return payScales;
    }


}
