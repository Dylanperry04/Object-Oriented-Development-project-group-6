public class PartTimeEmployee extends Employee {
    private double hourlyRate;
    private int hoursWorked;

    public PartTimeEmployee(String employeeId, String name, String title, int point, double hourlyRate, int hoursWorked) {
        super(employeeId, name, title, point);
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }

    @Override
    public double calculateGrossPay() {
        grossPay = hourlyRate * hoursWorked;
        return grossPay;
    }
}
