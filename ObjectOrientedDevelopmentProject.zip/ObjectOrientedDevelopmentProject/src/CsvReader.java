import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CsvReader {

    public static List<Employee> readEmployees(String fileName) throws IOException {
        List<Employee> employees = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line;
        reader.readLine(); // Skip header

        while ((line = reader.readLine()) != null) {
            String[] columns = line.split(",");
            String employeeId = columns[0];
            String name = columns[1];
            String title = columns[2];
            int point = Integer.parseInt(columns[3]);
            double annualRate = Double.parseDouble(columns[4]);
            double hourlyRate = Double.parseDouble(columns[5]);
            String employmentType = columns[6];

            if ("fulltime".equalsIgnoreCase(employmentType)) {
                employees.add(new FullTimeEmployee(employeeId, name, title, point, annualRate));
            } else {
                employees.add(new PartTimeEmployee(employeeId, name, title, point, hourlyRate, 160));
            }
        }
        reader.close();
        return employees;
    }

    public static List<Deductions> readDeductions(String fileName) throws IOException {
        List<Deductions> deductions = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line;
        reader.readLine(); // Skip header

        while ((line = reader.readLine()) != null) {
            String[] columns = line.split(",");
            String employeeId = columns[0];
            String deductionName = columns[1];
            double amount = Double.parseDouble(columns[2]);
            String effectiveDate = columns[3];

            deductions.add(new Deductions(employeeId, deductionName, amount, effectiveDate));
        }
        reader.close();
        return deductions;
    }

    public static List<Tax> readTaxes(String fileName) throws IOException {
        List<Tax> taxes = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line;
        reader.readLine(); // Skip header

        while ((line = reader.readLine()) != null) {
            String[] columns = line.split(",");
            String employeeId = columns[0];
            double taxAmount = Double.parseDouble(columns[4]);

            taxes.add(new Tax(employeeId, taxAmount));
        }
        reader.close();
        return taxes;
    }

    public static List<PayScale> readPayScales(String fileName) throws IOException {
        List<PayScale> payScales = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line;
        reader.readLine(); // Skip header

        while ((line = reader.readLine()) != null) {
            if (line.trim().isEmpty()) continue;

            String[] columns = line.split(",");
            if (columns.length < 4) continue;

            try {
                String title = columns[0].trim();
                int point = Integer.parseInt(columns[1].trim());
                double annualRate = Double.parseDouble(columns[2].trim());
                double hourlyRate = Double.parseDouble(columns[3].trim());

                payScales.add(new PayScale(title, point, annualRate, hourlyRate));
            } catch (NumberFormatException e) {
                System.err.println("Skipping line with invalid number format: " + line);
            }
        }
        reader.close();
        return payScales;
    }

    public static List<PayrollClaim> readClaims(String fileName) throws IOException {
        List<PayrollClaim> claims = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line;
        reader.readLine(); // Skip header

        while ((line = reader.readLine()) != null) {
            String[] columns = line.split(",");
            if (columns.length < 4) continue;

            String employeeId = columns[0];
            String claimDate = columns[1];
            double hoursWorked = Double.parseDouble(columns[2]);
            double hourlyRate = Double.parseDouble(columns[3]);

            claims.add(new PayrollClaim(employeeId, claimDate, hoursWorked, hourlyRate));
        }
        reader.close();
        return claims;
    }
}
