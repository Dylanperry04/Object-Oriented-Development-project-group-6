import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try {
            // Load data from CSV files
            List<Employee> employees = CsvReader.readEmployees("Employees.csv");
            List<Deductions> deductions = CsvReader.readDeductions("Deductions.csv");
            List<Tax> taxes = CsvReader.readTaxes("PayRoll.csv");
            List<PayScale> payScales = CsvReader.readPayScales("PayScale.csv");
            List<PayrollClaim> claims = CsvReader.readClaims("PayClaim.csv");

            // Generate payslips dynamically based on claims
            List<PayRollSystem> payslips = PayRollSystem.generatePayslips(employees, deductions, taxes, claims);

            // Command Line Interface (CLI)
            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println("\n=== UL Payroll System ===");
                System.out.println("Login as:");
                System.out.println("E - Employee");
                System.out.println("H - HR");
                System.out.println("A - Admin");
                System.out.println("Q - Quit");
                System.out.print("Enter your role: ");
                String role = scanner.nextLine().trim().toUpperCase();

                switch (role) {
                    case "E":
                        employeeMenu(payslips, scanner);
                        break;
                    case "H":
                        hrMenu(employees, payScales, scanner);
                        break;
                    case "A":
                        adminMenu(employees, payScales, scanner);
                        break;
                    case "Q":
                        System.out.println("Exiting system.");
                        return;
                    default:
                        System.out.println("Invalid input. Please try again.");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void employeeMenu(List<PayRollSystem> payslips, Scanner scanner) {
        System.out.println("\n=== Employee Menu ===");
        System.out.println("1. View Most Recent Payslip");
        System.out.println("2. View Payslip History");
        System.out.println("3. Logout");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                viewMostRecentPayslip(payslips, scanner);
                break;
            case 2:
                viewPayslipHistory(payslips, scanner);
                break;
            case 3:
                System.out.println("Logging out...");
                return;
            default:
                System.out.println("Invalid option.");
        }
    }

    private static void viewMostRecentPayslip(List<PayRollSystem> payslips, Scanner scanner) {
        System.out.print("Enter Employee ID: ");
        String employeeId = scanner.nextLine();
        PayRollSystem mostRecent = null;

        for (PayRollSystem payslip : payslips) {
            if (payslip.getEmployee().getEmployeeId().equalsIgnoreCase(employeeId)) {
                if (mostRecent == null || payslip.getPayDate().compareTo(mostRecent.getPayDate()) > 0) {
                    mostRecent = payslip;
                }
            }
        }

        if (mostRecent != null) {
            mostRecent.generatePayslip();
        } else {
            System.out.println("No payslip found for this employee.");
        }
    }

    private static void viewPayslipHistory(List<PayRollSystem> payslips, Scanner scanner) {
        System.out.print("Enter Employee ID: ");
        String employeeId = scanner.nextLine();

        // Filter payslips for the given Employee ID
        List<PayRollSystem> employeePayslips = payslips.stream()
                .filter(p -> p.getEmployee().getEmployeeId().equalsIgnoreCase(employeeId))
                .sorted((p1, p2) -> p2.getPayDate().compareTo(p1.getPayDate())) // Sort by PayDate (Descending)
                .toList();

        System.out.println("\n=== Payslip History ===");

        if (employeePayslips.isEmpty()) {
            System.out.println("No payslip history found for this employee.");
            return;
        }

        // Display up to the last 3 payslips
        for (int i = 0; i < Math.min(3, employeePayslips.size()); i++) {
            employeePayslips.get(i).generatePayslip();
        }
    }

    private static void hrMenu(List<Employee> employees, List<PayScale> payScales, Scanner scanner) {
        System.out.println("\n=== HR Menu ===");
        System.out.println("1. Promote Employee");
        System.out.println("2. Logout");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                promoteEmployee(employees, payScales, scanner);
                break;
            case 2:
                System.out.println("Logging out...");
                return;
            default:
                System.out.println("Invalid option.");
        }
    }

    private static void promoteEmployee(List<Employee> employees, List<PayScale> payScales, Scanner scanner) {
        System.out.print("Enter Employee ID to promote: ");
        String employeeId = scanner.nextLine();
        boolean promoted = false;

        for (Employee employee : employees) {
            if (employee.getEmployeeId().equalsIgnoreCase(employeeId) && employee instanceof FullTimeEmployee) {
                FullTimeEmployee fullTimeEmployee = (FullTimeEmployee) employee;
                fullTimeEmployee.promote(payScales);
                promoted = true;
                break;
            }
        }

        if (!promoted) {
            System.out.println("Employee not found or not eligible for promotion.");
        }
    }

    private static void adminMenu(List<Employee> employees, List<PayScale> payScales, Scanner scanner) {
        System.out.println("\n=== Admin Menu ===");
        System.out.println("1. Add Employee");
        System.out.println("2. Fire Employee");
        System.out.println("3. Logout");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                addEmployee(employees, payScales, scanner);
                break;
            case 2:
                fireEmployee(employees, scanner);
                break;
            case 3:
                System.out.println("Logging out...");
                return;
            default:
                System.out.println("Invalid option.");
        }
    }

    private static void addEmployee(List<Employee> employees, List<PayScale> payScales, Scanner scanner) {
        System.out.print("Enter Employee ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Title: ");
        String title = scanner.nextLine().toUpperCase();
        System.out.print("Enter Employment Type (fulltime/parttime): ");
        String type = scanner.nextLine().toLowerCase();
        System.out.print("Enter Point: ");
        int point = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        PayScale matchingPayScale = payScales.stream()
                .filter(p -> p.getTitle().equalsIgnoreCase(title) && p.getPoint() == point)
                .findFirst()
                .orElse(null);

        if (matchingPayScale == null) {
            System.out.println("Error: No matching pay scale found for the specified title and point.");
            return;
        }

        double annualRate = matchingPayScale.getAnnualRate();
        double hourlyRate = matchingPayScale.getHourlyRate();

        if (type.equals("fulltime")) {
            employees.add(new FullTimeEmployee(id, name, title, point, annualRate));
            appendEmployeeToCSV(id, name, title, point, annualRate, 0.0, "fulltime");
            System.out.println("Full-time employee added successfully!");
        } else if (type.equals("parttime")) {
            employees.add(new PartTimeEmployee(id, name, title, point, hourlyRate, 0));
            appendEmployeeToCSV(id, name, title, point, 0.0, hourlyRate, "parttime");
            System.out.println("Part-time employee added successfully!");
        } else {
            System.out.println("Invalid employment type. Employee not added.");
        }
    }

    private static void appendEmployeeToCSV(String employeeId, String name, String title, int point, double annualRate, double hourlyRate, String employmentType) {
        String csvFilePath = "Employees.csv";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(csvFilePath, true))) {
            String newEmployee = employeeId + "," + name + "," + title + "," + point + "," + annualRate + "," + hourlyRate + "," + employmentType;
            writer.write(newEmployee);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error writing to CSV file: " + e.getMessage());
        }
    }

    private static void fireEmployee(List<Employee> employees, Scanner scanner) {
        System.out.print("Enter Employee ID to fire: ");
        String employeeId = scanner.nextLine();

        // Find and remove the employee from the in-memory list
        Employee employeeToRemove = null;
        for (Employee employee : employees) {
            if (employee.getEmployeeId().equalsIgnoreCase(employeeId)) {
                employeeToRemove = employee;
                break;
            }
        }

        if (employeeToRemove != null) {
            employees.remove(employeeToRemove);
            System.out.println("Employee " + employeeToRemove.getName() + " has been removed.");

            // Update the CSV file after removal
            updateCSVAfterRemoval(employees);
        } else {
            System.out.println("Employee with ID " + employeeId + " not found.");
        }
    }

    // Helper method to update the CSV file
    private static void updateCSVAfterRemoval(List<Employee> employees) {
        String csvFilePath = "employees.csv";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(csvFilePath))) {
            // Write the CSV header
            writer.write("EmployeeID,Name,Title,Point,AnnualRate,HourlyRate,EmploymentType");
            writer.newLine();

            // Write the updated employee list
            for (Employee employee : employees) {
                String line = employee.getEmployeeId() + "," +
                              employee.getName() + "," +
                              employee.getTitle() + "," +
                              employee.getPoint() + "," +
                              (employee instanceof FullTimeEmployee ? ((FullTimeEmployee) employee).calculateGrossPay() : 0) + "," +
                              (employee instanceof PartTimeEmployee ? ((PartTimeEmployee) employee).calculateGrossPay() : 0) + "," +
                              (employee instanceof FullTimeEmployee ? "fulltime" : "parttime");
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error updating CSV file: " + e.getMessage());
        }
    }

}
