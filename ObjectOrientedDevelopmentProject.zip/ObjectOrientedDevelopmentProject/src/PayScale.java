public class PayScale {
    private String title;
    private int point;
    private double annualRate;
    private double hourlyRate;

    public PayScale(String title, int point, double annualRate, double hourlyRate) {
        this.title = title;
        this.point = point;
        this.annualRate = annualRate;
        this.hourlyRate = hourlyRate;
    }

    public String getTitle() {
        return title;
    }

    public int getPoint() {
        return point;
    }

    public double getAnnualRate() {
        return annualRate;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }
}