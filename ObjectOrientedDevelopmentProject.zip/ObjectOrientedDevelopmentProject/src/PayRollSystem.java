import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class PayRollSystem {
    private Employee employee;
    private List<Deductions> deductionsList;
    private double taxes;
    private double netPay;
    private YearMonth payDate;
    private double carryOverPay;

    // Updated constructor
    public PayRollSystem(Employee employee, List<Deductions> deductionsList, double taxes, double carryOverPay, String payDate) {
        this.employee = employee;
        this.deductionsList = deductionsList;
        this.taxes = taxes;
        this.carryOverPay = carryOverPay;
        this.payDate = YearMonth.parse(payDate, DateTimeFormatter.ofPattern("yyyy-MM"));
        this.netPay = calculateNetPay();
    }

    // Method to calculate net pay
    private double calculateNetPay() {
        double totalDeductions = Deductions.calculateTotalDeductions(deductionsList, employee.getEmployeeId());
        double grossPay = employee.calculateGrossPay();
        return roundToTwoDecimals((grossPay + carryOverPay) - totalDeductions - taxes);
    }

    // Utility to round to two decimals
    private double roundToTwoDecimals(double value) {
        return BigDecimal.valueOf(value).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    // Getters
    public YearMonth getPayDate() {
        return payDate;
    }

    public double getTaxes() {
        return roundToTwoDecimals(taxes);
    }

    public double getNetPay() {
        return netPay;
    }

    public Employee getEmployee() {
        return employee;
    }

    // Method to display payslip
    public void generatePayslip() {
        System.out.println("\n=== Pay Slip ===");
        System.out.println("Employee ID: " + employee.getEmployeeId());
        System.out.println("Name: " + employee.getName());
        System.out.println("Title: " + employee.getTitle());
        System.out.printf("Gross Pay: %.2f%n", employee.calculateGrossPay());
        System.out.printf("Carry-Over Pay: %.2f%n", carryOverPay);
        System.out.printf("Total Deductions: %.2f%n", Deductions.calculateTotalDeductions(deductionsList, employee.getEmployeeId()));
        System.out.printf("Taxes: %.2f%n", taxes);
        System.out.printf("Net Pay: %.2f%n", netPay);
        System.out.println("Pay Date: " + payDate.format(DateTimeFormatter.ofPattern("yyyy-MM")));
        System.out.println("-----------------------------");
    }

    // Static method to generate payslips
    public static List<PayRollSystem> generatePayslips(List<Employee> employees, List<Deductions> deductions, List<Tax> taxes, List<PayrollClaim> claims) {
        List<PayRollSystem> payslips = new ArrayList<>();

        for (Employee employee : employees) {
            // Filter deductions for the employee
            List<Deductions> employeeDeductions = new ArrayList<>();
            double employeeTax = 0.0;

            for (Deductions deduction : deductions) {
                if (deduction.getEmployeeId().equalsIgnoreCase(employee.getEmployeeId())) {
                    employeeDeductions.add(deduction);
                }
            }

            // Find taxes for the employee
            for (Tax tax : taxes) {
                if (tax.getEmployeeId().equalsIgnoreCase(employee.getEmployeeId())) {
                    employeeTax = tax.getTaxAmount();
                }
            }

            // Process each claim for the employee
            for (PayrollClaim claim : claims) {
                if (claim.getEmployeeId().equalsIgnoreCase(employee.getEmployeeId())) {
                    String payDateForClaim = claim.getClaimDate().format(DateTimeFormatter.ofPattern("yyyy-MM"));
                    double carryOverPay = claim.getHoursWorked() * claim.getHourlyRate();

                    // Create a payslip for this claim
                    PayRollSystem payslip = new PayRollSystem(employee, employeeDeductions, employeeTax, carryOverPay, payDateForClaim);
                    payslips.add(payslip);
                }
            }
        }

        return payslips;
    }
}
