import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class PayrollClaim {
    private String employeeId;
    private LocalDate claimDate;
    private double hoursWorked;
    private double hourlyRate;

    public PayrollClaim(String employeeId, String claimDate, double hoursWorked, double hourlyRate) {
        this.employeeId = employeeId;
        this.claimDate = LocalDate.parse(claimDate, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public LocalDate getClaimDate() {
        return claimDate;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    public boolean isLate() {
        return claimDate.getDayOfMonth() >= 25;
    }
}

