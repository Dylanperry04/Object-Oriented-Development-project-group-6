import java.util.List;

public class FullTimeEmployee extends Employee {
    private double annualRate;

    public FullTimeEmployee(String employeeId, String name, String title, int point, double annualRate) {
        super(employeeId, name, title, point);
        this.annualRate = annualRate;
    }

    @Override
    public double calculateGrossPay() {
        return annualRate / 12; // Monthly salary
    }

    public void promote(List<PayScale> payScales) {
        for (PayScale payScale : payScales) {
            if (payScale.getTitle().equalsIgnoreCase(this.title) && payScale.getPoint() == this.point + 1) {
                this.point++;
                this.annualRate = payScale.getAnnualRate();
                System.out.println("Employee " + this.getName() + " promoted to point " + this.point + " with annual rate " + this.annualRate);
                return;
            }
        }

        System.out.println("No promotion available for " + this.getName() + " at point " + this.point);
    }
}
