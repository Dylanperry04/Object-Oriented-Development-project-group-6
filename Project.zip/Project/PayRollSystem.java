import java.util.*;

public class PayRollSystem {
    private Employee employee;
    private List<Deductions> deductionsList;
    private double taxes;

    public PayRollSystem(Employee employee, List<Deductions> deductionsList, double taxes) {
        this.employee = employee;
        this.deductionsList = deductionsList;
        this.taxes = taxes;
    }

    // Calculate net pay (gross pay - deductions - taxes)
    public double calculateNetPay() {
        double totalDeductions = Deductions.calculateTotalDeductions(deductionsList);
        double grossPay = employee.calculateGrossPay();  // Call getGrossPay() from Employee class
        return grossPay - totalDeductions - taxes;  // Net pay is gross pay - deductions - taxes
    }

    public double getTaxes() {
        return taxes;
    }

    // Print payslip details
    public void printPayslip() {
        double grossPay = employee.calculateGrossPay();  // Call getGrossPay() here as well
        double totalDeductions = Deductions.calculateTotalDeductions(deductionsList);
        double netPay = calculateNetPay();

        System.out.println("=== Pay Slip ===");
        System.out.printf("%-20s %-6s %-10s %-10s %-20s %-10s\n", "Title", "Point", "Net Pay", "Gross Pay", "Deductions", "Taxes");
        System.out.println("---------------------------------------------------------------");

        System.out.printf("%-20s %-6d %-10.2f %-10.2f %-20s %-10.2f\n",
                employee.getTitle(),
                employee.getPoint(),
                netPay,
                grossPay,
                getFormattedDeductions(),
                getTaxes());

        System.out.println("---------------------------------------------------------------");
    }

    // Format deductions for printing
    private String getFormattedDeductions() {
        StringBuilder formattedDeductions = new StringBuilder();
        for (Deductions deduction : deductionsList) {
            formattedDeductions.append(deduction.getDeductionName()).append(": ").append(deduction.getAmount()).append(" | ");
        }
        if (formattedDeductions.length() > 0) {
            formattedDeductions.delete(formattedDeductions.length() - 2, formattedDeductions.length());
        }
        return formattedDeductions.toString();
    }
}
