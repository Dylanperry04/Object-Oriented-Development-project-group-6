import java.io.*;
import java.util.*;

public class CsvReader {

    public static void main(String[] args) {
        try {
            List<Employee> employees = readEmployees("employees.csv");
            List<Deductions> deductions = readDeductions("deductions.csv");
            List<PayRollSystem> payslips = generatePayslips(employees, deductions);

            for (PayRollSystem payslip : payslips) {
                payslip.printPayslip();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static List<Employee> readEmployees(String fileName) throws IOException {
        List<Employee> employees = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line;
        reader.readLine();  // Skip header row

        while ((line = reader.readLine()) != null) {
            String[] columns = line.split(",");

            // Read employeeId as String instead of parsing it to Integer
            String employeeId = columns[0];  // Changed to String
            String name = columns[1];
            String title = columns[2];
            int point = Integer.parseInt(columns[3]);
            double annualRate = Double.parseDouble(columns[4]);
            double hourlyRate = Double.parseDouble(columns[5]);
            String employmentType = columns[6];

            if ("fulltime".equalsIgnoreCase(employmentType)) {
                employees.add(new FullTimeEmployee(employeeId, name, title, point, annualRate));
            } else {
                employees.add(new PartTimeEmployee(employeeId, name, title, point, hourlyRate, 160));  // Assuming 160 hours worked for part-time
            }
        }
        reader.close();
        return employees;
    }

    private static List<Deductions> readDeductions(String fileName) throws IOException {
        List<Deductions> deductions = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line;
        reader.readLine();  // Skip header row

        while ((line = reader.readLine()) != null) {
            String[] columns = line.split(",");
            String employeeId = columns[0];  // Read employeeId as String
            String deductionName = columns[1];
            double amount = Double.parseDouble(columns[2]);
            String effectiveDate = columns[3];
            deductions.add(new Deductions(employeeId, deductionName, amount, effectiveDate));  // Store employeeId as String
        }
        reader.close();
        return deductions;
    }

    private static List<PayRollSystem> generatePayslips(List<Employee> employees, List<Deductions> deductions) {
        List<PayRollSystem> payslips = new ArrayList<>();
        double taxes = 12000.00;  // Example of fixed tax for all employees

        for (Employee employee : employees) {
            List<Deductions> employeeDeductions = new ArrayList<>();

            // Filter deductions for the current employee based on employeeId
            for (Deductions deduction : deductions) {
                if (deduction.getEmployeeId().equals(employee.getEmployeeId())) {
                    employeeDeductions.add(deduction);
                }
            }

            // Create the payslip with the filtered deductions and taxes
            PayRollSystem payslip = new PayRollSystem(employee, employeeDeductions, taxes);
            payslips.add(payslip);
        }

        return payslips;
    }
}
