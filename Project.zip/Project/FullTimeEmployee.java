public class FullTimeEmployee extends Employee {
    private double annualRate;

    public FullTimeEmployee(String employeeId, String name, String title, int point, double annualRate) {
        super(employeeId, name, title, point);
        this.annualRate = annualRate;
    }

    @Override
    public double calculateGrossPay() {
        grossPay = annualRate / 12;  // Monthly gross pay calculation
        return grossPay;
    }
}
