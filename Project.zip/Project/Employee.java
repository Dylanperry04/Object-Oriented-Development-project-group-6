public abstract class Employee {
    protected String employeeId;
    protected String name;
    protected String title;
    protected int point;
    protected double grossPay;

    public Employee(String employeeId, String name, String title, int point) {
        this.employeeId = employeeId;
        this.name = name;
        this.title = title;
        this.point = point;
    }

    public abstract double calculateGrossPay();

    public String getEmployeeId() {
        return employeeId;
    }


    public double getGrossPay() {
        return grossPay;
    }

    public String getTitle() {
        return title;
    }

    public int getPoint() {
        return point;
    }

    public String getName() {
        return name;
    }
}