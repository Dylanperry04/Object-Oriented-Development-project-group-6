import java.util.*;
public class Deductions {
    private String employeeId;  // Added employeeId to match deductions to employees
    private String deductionName;
    private double amount;
    private String effectiveDate;

    public Deductions(String employeeId, String deductionName, double amount, String effectiveDate) {
        this.employeeId = employeeId;
        this.deductionName = deductionName;
        this.amount = amount;
        this.effectiveDate = effectiveDate;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public String getDeductionName() {
        return deductionName;
    }

    public double getAmount() {
        return amount;
    }

    public String getEffectiveDate() {
        return effectiveDate;
    }

    public static double calculateTotalDeductions(List<Deductions> deductionsList) {
        double total = 0;
        for (Deductions deduction : deductionsList) {
            total += deduction.getAmount();
        }
        return total;
    }
}
